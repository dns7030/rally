const envList = [{"envId":"cloud1-7gdqvjb7dd0c470b","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}