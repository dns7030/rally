const formatDate = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  return [year,month, day].map(formatNumber).join('-')
}

const formatTime = date => {
  const hour = date.getHours()
  const minute = date.getMinutes()
  return [hour, minute].map(formatNumber).join(':')
}

const formatShortDate = date => {
  const shortDate = date.toDateString().split(" ")
  return {
    "date": `${shortDate[0]} ${shortDate[1]} ${shortDate[2]}`,
    "time": `${formatNumber (date.getHours())} : ${formatNumber(date.getMinutes())}`
  }
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}


function formatLocation(longitude, latitude) {
  if (typeof longitude === 'string' && typeof latitude === 'string') {
    longitude = parseFloat(longitude)
    latitude = parseFloat(latitude)
  }

  longitude = longitude.toFixed(2)
  latitude = latitude.toFixed(2)

  return {
    longitude: longitude.toString().split('.'),
    latitude: latitude.toString().split('.')
  }
}

module.exports = {
  formatDate: formatDate,
  formatTime: formatTime,
  formatShortDate: formatShortDate
}
