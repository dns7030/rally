Page({

  /**
   * 页面的初始数据
   */
  data: {
    showUploadTip: false,
    haveGetImgSrc: false,
    envId: '',
    imgSrc: ''
  },

  onLoad(options) {
    this.setData({
      envId: options.envId
    })
  },

  
  uploadImg: function(e) {
    let page = this
    console.log('checking upload image', e)

    // 让用户选择一张图片
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],

      success: function(res) {
        console.log('Checking tempFile link', res)
        const tempFilePaths = res.tempFilePaths
        for (let i = 0; i < tempFilePaths.length; i += 1) {
        }
        page.setData({
        imgSrc:res.tempFilePaths
        })


        console.log('image link ', tempFilePaths[0])

        let MyFile = new wx.BaaS.File()
        let fileParams = {filePath: res.tempFilePaths[0]}
        let metaData = {categoryName: 'SDK'}

        MyFile.upload(fileParams, metaData).then(res => {
          let data = res.data  // res.data 为 Object 类型
        }, err => {
          // err
        }).onProgressUpdate(e => {
          // 监听上传进度
          console.log(e)
        })

      }, 
    });
  },
  
  clearImgSrc() {
    this.setData({
      haveGetImgSrc: false,
      imgSrc: ''
    })
  }

})
