// pages/event/event.js
const app = getApp()
const util = require("../../utils/util")
const moment = require("../../js/moment.js")
const extraLine= []
const picker = []

Page({

  data: {
    hiddenName:true,
    formData: {},
    date: '',
    hasLocation: false,
    event: {},
    events: [],
    date: 'Date',
    date2: 'Optional',
    time: 'Time',
    time2:'Optional',
    canAdd: true,
    show: false,
    index: 0,//选择的下拉列表下标
    searchInput: [],
    selectData: [],
    item: '',
    longitude: '',
    latitude: '',
    address: '',
    name: '',
    showUploadTip: false,
    haveGetImgSrc: false,
    envId: '',
    imgSrc: ''
  },

  selectTap() {
    this.setData({
      show: !this.data.show
    });
  },
  uploadImg: function(e) {
    let page = this
    console.log('checking upload image', e)

    // 让用户选择一张图片
    wx.chooseImage({
      count: 3,
      sizeType: ['original'],
      sourceType: ['album', 'camera'],

      success: function(res) {
        console.log('Checking tempFile link', res)
        const tempFilePaths = res.tempFilePaths
        //for (let i = 0; i < tempFilePaths.length; i += 1) {}
        page.setData({
        imgSrc:res.tempFilePaths
        })


        console.log('image link ', tempFilePaths[0])

        let MyFile = new wx.BaaS.File()
        let fileParams = {filePath: res.tempFilePaths[0]}
        let metaData = {categoryName: 'SDK'}
        MyFile.upload(fileParams, metaData).then(res => {
          // Upload successful
          let data = res.data 
        }, error => {
          // Uh-oh, something happened
        })

 
      }, 
    });
  },
  getLocation: function(e) {
    console.log('checking map button', e)
    const that = this
    type: 'wgs84',
    wx.chooseLocation({
      success(res){
        console.log('successful location', res)
        const latitude = res.latitude
        const longitude = res.longitude
        
        that.setData({
          hasLocation: true,
          longitude: res.longitude,
          latitude: res.latitude,
          address: res.address,
          name: res.name,
        })
      },
      fail(res){
        console.log('failed location', res)
      }
    })
  },

  /**Pick a date and time */
  bindDateChange1: function(e) {
    console.log('bindDateChange 1', e);
    this.setData({
       date: e.detail.value,    
    })
  },
  bindDateChange2: function(e) {
    console.log('bindDateChange 2', e);
    this.setData({
       date2: e.detail.value,    
    })
  },
  bindTimeChange1(e) {
    console.log('bindTimeChange', e);
    this.setData({
      time: e.detail.value,
    })
  },
  bindTimeChange2(e) {
    console.log('bindTimeChange 2', e);
    this.setData({
      time2: e.detail.value
    })
  },
  /**Add more date option button */

  add: function (e) {
    console.log('checking add button')
    const test = wx.createSelectorQuery().select('.;input-date2');
    this.setData({
      hiddenName:!this.data.hiddenName
    })
  },

  formSubmit: function (event) {   

    let formData = event.detail.value
    let currentUser = this.data.currentUser
    let events = new wx.BaaS.TableObject('events');
    let newEvent = events.create();

    if (!currentUser) {
      wx.switchTab({
        url: '/pages/user/user' // logged in
      });
    };
    let title = event.detail.value.title;
    let description = event.detail.value.description;
    let date = event.detail.value.date;
    let date2 = event.detail.value.date2;
    let time = event.detail.value.time;
    let time2 = event.detail.value.time2;
    let tempFilePaths = event.detail.value.imgPath;

    //combined date and time by momentjs
    var momentObj = moment(date + 'T' + time + '+08:00' , 'YYYY-MM-DDLT');
    var dateTime = momentObj.clone();
    var momentObj2 = moment(date2 + 'T' + time2 + '+08:00' , 'YYYY-MM-DDLT');
    var dateTime2 = momentObj2.clone('YYYY-MM-DDTHH:mm:s');
    console.log('dateTime combination', dateTime._i);
    console.log('dateTime combination 2', dateTime2._i);

    //location
    formData.longitude = this.data.longitude;
    formData.latitude = this.data.latitude;
    formData.address = this.data.address;
    formData.name = this.data.name;

    console.log('created new event', event)

    const data = {
      title: title,
      description: description,
      date: [dateTime._i, dateTime2._i],
      longitude: this.data.longitude,
      latitude: this.data.latitude,
      address: this.data.address,
      name: this.data.name,
      imgSrc: this.tempFilePaths
    }

console.log('checking created data', data)

    newEvent.set(data);
    // Post data to API
    newEvent.save().then((res) => {
        console.log('save newEvent', res);
        const newEvents = this.data.events;
        newEvents.push(res.data);

        this.setData({
          event: newEvents,
        })


        wx.navigateTo({
          url: `/pages/description/description?id=${newEvents[0]._id}`,
        })
        console.log('complete new event sent by now', newEvents[0]._id)
    })


    wx.showToast({
      title: "Let's go!",
      icon: 'success',
      duration: 4000,
      mask: true,
    });
  },
  
  formReset(e) {
    console.log('form发生了reset事件，携带数据为：', e.detail.value)
    this.setData({
      chosen: '',
      hasLocation: false,
      date: 'Date',
      time: 'Time',
      date2: 'Optional',
      time2: 'Optional'

    })
  },
  onClickSearchButton: function (event) {
    console.log('checking search', event)
  },
})
