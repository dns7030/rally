// pages/user/user.js
const util = require("../../utils/util");

let app= getApp()
Page({

  data: {
    currentUser: null,
    events: {},
    active: 0,
    events: {},
    date: [],
    time: []
  },

  onLoad: function (options) {
    console.log('checking getting user data', app.globalData.userInfo);
    
    this.setData({
      currentUser: app.globalData.userInfo
    });
    const events = new wx.BaaS.TableObject('events');
    let query = new wx.BaaS.Query();
    events.setQuery(query).expand(["venue.id"]).limit(100).find().then((res) => {
        console.log('checking event expand',res)
        let events = res.data.objects
        let formatedEvents = []

        events.forEach((event)=>{
          event.date = event.date.map(date => {
            return util.formatShortDate(new Date(date));
          });
          formatedEvents.push(event)
        })
    })
  },
  userInfoHandler(data) {
    const app = getApp();
    wx.BaaS.auth.loginWithWechat(data).then(user => {
      console.log('user', user);
        app.globalData.userInfo = user;
        // wx.setStorageSync('userInfo', user);
        this.setData({
          currentUser: user,
        })
      }, err => {
    })
  },

  _switchTab: function(e) {
    console.log(e.currentTarget.dataset.tab)
    let activeTab =  e.currentTarget.dataset.tab
    this.setData({
      active: activeTab
    })
  },  

})