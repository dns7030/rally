# rally

Rally is the first Wechat Mini-program that I am building since I finished Le Wagon Coding Bootcamp.

In this code I fairlty worked on both front-end and back-end.
