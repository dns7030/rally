// pages/event/event.js
const app = getApp()
const util = require("../../utils/util")
const moment = require("../../js/moment.js")
const extraLine= []
const picker = []

Page({

  data: {
    hiddenName:true,
    formData: {},
    date: '',
    hasLocation: false,
    event: {},
    events: [],
    date: 'Date',
    date2: 'Optional',
    time: 'Time',
    time2:'Optional',
    canAdd: true,
    show: false,
    index: 0,//选择的下拉列表下标
    searchInput: [],
    selectData: [],
    item: '',
    longitude: '',
    latitude: '',
    address: '',
    name: '',
  },

  selectTap() {
    this.setData({
      show: !this.data.show
    });
  },

  /**search venue fro API function */
  getSearchInput: function (e){
    let name_en = new wx.BaaS.TableObject('venues')
    let selectData = new wx.BaaS.TableObject('venues')
    let query = new wx.BaaS.Query()
    console.log('set BaaS', e.detail)
    query.contains('name_en', e.detail.value)
    selectData.setQuery(query).find().then((res) => {
      console.log('checking search query',res)
      // store data and display data
      this.setData({
        selectData: res.data.objects,
      })
    })
    console.log(e.detail.value)
  },

  selectResult(e) {
    let venueID = e.currentTarget.dataset.id;
    let keyword = e.currentTarget.dataset.name;
    
    this.setData({
      selectvenueID: venueID,
      searchInput: keyword
    })
  },

  searchSubmitFn: function (e) {
    console.log(e)
    var that = this
    var searchInput = this.data.searchInput
    var searchRecord = this.data.searchRecord
    if (searchInput == '') {
    }
    else {
      let arrnum = searchRecord.indexOf(searchInput);

      if (arrnum==-1){
        searchRecord.unshift(searchInput)
        //将历史记录数组整体储存到缓存中
      }
      else{
        // 删除已存在后重新插入至数组
        searchRecord.splice(arrnum, 1)
        searchRecord.unshift(searchInput)
      }
      wx.setStorageSync('searchRecord', searchRecord)

    }
    this.setData({
      searchRecord: this.data.searchRecord
    })
  },

  getLocation: function(e) {
    const that = this
    wx.chooseLocation({
      success(res){
        console.log('chosen location',res)
        that.setData({
          hasLocation: true,
          longitude: res.longitude,
          latitude: res.latitude,
          address: res.address,
          name: res.name,
        })
      }
    })
  },
  /**Pick a date and time */

  bindDateChange1: function(e) {
    console.log('bindDateChange 1', e);
    this.setData({
       date: e.detail.value,    
    })
  },
  bindDateChange2: function(e) {
    console.log('bindDateChange 2', e);
    this.setData({
       date2: e.detail.value,    
    })
  },

  bindTimeChange1(e) {
    console.log('bindTimeChange', e);
    this.setData({
      time: e.detail.value,
    })
  },
  bindTimeChange2(e) {
    console.log('bindTimeChange 2', e);
    this.setData({
      time2: e.detail.value
    })
  },
  /**Add more date option button */

  add: function (e) {
    console.log('checking add button')
    const test = wx.createSelectorQuery().select('.;input-date2');
    this.setData({
      hiddenName:!this.data.hiddenName
    })
  },

  formSubmit: function (event) {   

    let formData = event.detail.value
    let currentUser = this.data.currentUser
    let events = new wx.BaaS.TableObject('events');
    let newEvent = events.create();

    if (!currentUser) {
      wx.switchTab({
        url: '/pages/user/user' // logged in
      });
    };

    let title = event.detail.value.title;
    let description = event.detail.value.description;
    let date = event.detail.value.date;
    let date2 = event.detail.value.date2;
    let time = event.detail.value.time;
    let time2 = event.detail.value.time2;

    //combined date and time by momentjs
    var momentObj = moment(date + 'T' + time + '+08:00' , 'YYYY-MM-DDLT');
    var dateTime = momentObj.clone();
    var momentObj2 = moment(date2 + 'T' + time2 + '+08:00' , 'YYYY-MM-DDLT');
    var dateTime2 = momentObj2.clone('YYYY-MM-DDTHH:mm:s');
    console.log('dateTime combination', dateTime._i);
    console.log('dateTime combination 2', dateTime2._i);

    //location
    formData.longitude = this.data.longitude;
    formData.latitude = this.data.latitude;
    formData.address = this.data.address;
    formData.name = this.data.name;

    console.log('created new event', event)

    const data = {
      title: title,
      description: description,
      date: [dateTime._i, dateTime2._i],
      longitude: this.data.longitude,
      latitude: this.data.latitude,
      address: this.data.address,
      name: this.data.name
    }

console.log('checking created data', data)

    newEvent.set(data);
    
    // Post data to API
    newEvent.save().then((res) => {
        console.log('save newEvent', res);
        const newEvents = this.data.events;
        newEvents.push(res.data);

        this.setData({
          event: newEvents,
        })


        wx.navigateTo({
          url: `/pages/description/description?id=${newEvents[0]._id}`,
        })
        console.log('complete new event sent by now', newEvents[0]._id)
    })


    wx.showToast({
      title: "Let's go!",
      icon: 'success',
      duration: 4000,
      mask: true,
    });
  },
  
  formReset(e) {
    console.log('form发生了reset事件，携带数据为：', e.detail.value)
    this.setData({
      chosen: '',
      hasLocation: false,
      date: 'Date',
      time: 'Time',
      date2: 'Optional',
      time2: 'Optional'

    })
  },
  onClickSearchButton: function (event) {
    console.log('checking search', event)
  },
})
