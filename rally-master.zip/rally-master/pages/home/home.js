// pages/user/user.js
const util = require("../../utils/util");

let app= getApp()
Page({

  data: {
    currentUser: null,
    events: {}
  },

  showEvents: function(event) {
    let data = event.currentTarget.dataset;
    let id = data.id;

    console.log('checking id', id)
    wx.navigateTo({
      url: `/pages/description/description?id=${id}`
    });
  },

  onLoad: function (options) {
    console.log('checking getting user data', app.globalData.userInfo);
    
    this.setData({
      currentUser: app.globalData.userInfo
    });
    let currentUser = this.data.currentUser;
    let events = allEvents
    const allEvents = new wx.BaaS.TableObject('events');
    let query = new wx.BaaS.Query();
    allEvents.setQuery(query).limit(100).find().then((res) => {
      console.log('checking all events data',res)
      
      const futureEvents = events.filter(event => {
        console.log('other event future Event', event.event_id)

        const eventDate = new Date(event.date[0]).getTime();
        if(eventDate > now) {
          return true;
        }
        return false;
      });
      
      this.setData ({
        events: res.data.objects
      })
    });


    },

  userInfoHandler(data) {
    const app = getApp();
    wx.BaaS.auth.loginWithWechat(data).then(user => {
      console.log('user', user);
        app.globalData.userInfo = user;
        // wx.setStorageSync('userInfo', user);
        this.setData({
          currentUser: user,
        })
      }, err => {
    })
  },
  
  filterExpiredEvents: function(allEvents) {
    let now = new Date();
    const filteredEvents = allEvents.filter((event) => {
      if(!event.startTime) return false;
  
      if(new Date(event.date).getTime() < now.getTime() + 1800000) {
        return false;
      }
      return true;
    }).map(event => {
      return {
        ...event,
        date: moment(events.date).utcOffset(events.date).format("YYYY-MM-DD hh:mm")
      }
    });
  
    // return filtered events
    return filteredEvents;
  },

  _switchTab: function(e) {
    console.log(e.currentTarget.dataset.tab)
    let activeTab =  e.currentTarget.dataset.tab
    this.setData({
      active: activeTab
    })
  },
 
  onReady: function () {
    this.setData({
      events: app.globalData.events
    })
  },


})